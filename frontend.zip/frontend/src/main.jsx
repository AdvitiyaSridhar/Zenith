import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import './index.css';

const API_BASE = 'http://127.0.0.1:8000';

function riskLevelColor(level) {
  if (!level) return '#6b6375';
  switch (level) {
    case 'critical': return '#dc2626';
    case 'high': return '#f59e0b';
    case 'medium': return '#eab308';
    case 'low': return '#10b981';
    default: return '#6b6375';
  }
}

function App() {
  const [state, setState] = useState({
    assets: [], vulns: [], threats: [], controls: [],
    riskAssessments: [], invOpts: [], scenarios: [],
    riskLevels: {}, recs: []
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function init() {
      try {
        const [
          assets, vulns, threats, controls,
          riskAssessments, invOpts, scenarios, recs
        ] = await Promise.all([
          fetch(`${API_BASE}/api/v1/assets`).then(r => r.json()),
          fetch(`${API_BASE}/api/v1/vulnerabilities`).then(r => r.json()),
          fetch(`${API_BASE}/api/v1/threats`).then(r => r.json()),
          fetch(`${API_BASE}/api/v1/controls`).then(r => r.json()),
          fetch(`${API_BASE}/api/v1/risk-assessments`).then(r => r.json()),
          fetch(`${API_BASE}/api/v1/investment-options`).then(r => r.json()),
          fetch(`${API_BASE}/api/v1/scenarios`).then(r => r.json()),
          fetch(`${API_BASE}/api/v1/recommendations/prioritized`).then(r => r.json())
        ]);

        const riskLevels = {};
        for (const a of assets) {
          const ra = riskAssessments.find(r => r.asset_id === a.id);
          if (ra) {
            riskLevels[a.id] = ra.risk_level;
          }
        }

        setState({
          assets, vulns: vulns, threats: threats, controls,
          riskAssessments, invOpts: invOpts, scenarios, recs,
          riskLevels
        });
      } catch (err) {
        console.error('Failed to initialize dashboard:', err);
      } finally {
        setLoading(false);
      }
    }
    init();
  }, []);

  const { assets, vulns, threats, controls, riskAssessments, invOpts, scenarios, recs, riskLevels } = state;

  const getRiskLevelColor = (level) => {
    if (!level) return '#6b6375';
    switch (level) {
      case 'critical': return '#dc2626';
      case 'high': return '#f59e0b';
      case 'medium': return '#eab308';
      case 'low': return '#10b981';
      default: return '#6b6375';
    }
  };

  const chip = (label) => `<span class="chip">${label}</span>`;

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '20px' }}>
      {loading ? (
        <div style={{ textAlign: 'center', padding: '40px', color: '#6b6375' }}>
          <h2>SIH26105 Platform</h2>
          <p>Loading dashboard data...</p>
        </div>
      ) : (
        <div style={{ margin: '24px auto', maxWidth: '1200px' }}>
          {/* Nav */}
          <div style={{
            background: '#f8f9fa', padding: '16px 24px', borderBottom: '1px solid #e5e4e7',
            margin: '-20px -20px 24px', display: 'flex', gap: '8px', overflowX: 'auto'
          }}>
            <a href="#assets" style={{ color: '#6b6375', textDecoration: 'none', padding: '8px 12px', borderRadius: '4px', background: '#f0f0f0', display: 'inline-block', margin: '0 4px' }}>Assets</a>
            <a href="#vuln" style={{ color: '#6b6375', textDecoration: 'none', padding: '8px 12px', borderRadius: '4px', background: '#f0f0f0', display: 'inline-block', margin: '0 4px' }}>Vulns</a>
            <a href="#threat" style={{ color: '#6b6375', textDecoration: 'none', padding: '8px 12px', borderRadius: '4px', background: '#f0f0f0', display: 'inline-block', margin: '0 4px' }}>Threats</a>
            <a href="#ctrl" style={{ color: '#6b6375', textDecoration: 'none', padding: '8px 12px', borderRadius: '4px', background: '#f0f0f0', display: 'inline-block', margin: '0 4px' }}>Controls</a>
            <a href="#risk" style={{ color: '#6b6375', textDecoration: 'none', padding: '8px 12px', borderRadius: '4px', background: '#f0f0f0', display: 'inline-block', margin: '0 4px' }}>Risk</a>
            <a href="#invest" style={{ color: '#6b6375', textDecoration: 'none', padding: '8px 12px', borderRadius: '4px', background: '#f0f0f0', display: 'inline-block', margin: '0 4px' }}>Invest</a>
            <a href="#scenario" style={{ color: '#6b6375', textDecoration: 'none', padding: '8px 12px', borderRadius: '4px', background: '#f0f0f0', display: 'inline-block', margin: '0 4px' }}>Scenario</a>
            <a href="#rec" style={{ color: '#6b6375', textDecoration: 'none', padding: '8px 12px', borderRadius: '4px', background: '#f0f0f0', display: 'inline-block', margin: '0 4px' }}>Recs</a>
          </div>

          {/* Assets / Risk Overview */}
          <div id="assets" style={{ marginBottom: '32px' }}>
            <h2 style={{ fontSize: '18px', fontWeight: '500', color: '#08060d', marginBottom: '16px' }}>Risk Overview</h2>
            <div style={{
              display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '16px'
            }}>
              {assets.map((a) => {
                const rl = riskLevels[a.id] || '—';
                const color = getRiskLevelColor(rl);
                return (
                  <div key={a.id} style={{
                    background: 'white', border: '1px solid #e5e4e7', borderRadius: '8px',
                    padding: '24px', margin: '16px 0', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1), 0 4px 6px -2px rgba(0,0,0,0.05)'
                  }}>
                    <h3 style={{ margin: '0 0 8px 0' }}>{a.name}</h3>
                    <p>
                      Criticality: <span style={{ display: 'inline-block', padding: '2px 6px', background: '#e5e4e7', borderRadius: '4px', fontSize: '12px', margin: '2px' }}>{a.criticality}</span> | Risk: <span style={{ display: 'inline-block', padding: '2px 6px', background: color !== 'undefined' ? color : '#e5e4e7', color: 'white', borderRadius: '4px', fontSize: '12px', margin: '2px 0', verticalAlign: 'middle' }}>{rl}</span>
                    </p>
                    <button style={{
                      display: 'block', width: '100%', padding: '8px 16px', background: '#aa3bff', color: 'white',
                      border: 'none', borderRadius: '4px', cursor: 'pointer', fontSize: '14px', marginTop: '8px'
                    }}>View Risk</button>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Risk Assessments Table */}
          <div id="risk" style={{ marginBottom: '32px' }}>
            <h2 style={{ fontSize: '18px', fontWeight: '500', color: '#08060d', marginBottom: '16px' }}>Risk Assessments</h2>
            <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '12px' }}>
              <thead>
                <tr style={{ background: '#f8f9fa', color: '#6b6375' }}>
                  <th style={{ padding: '8px', textAlign: 'left' }}>Asset</th>
                  <th style={{ padding: '8px', textAlign: 'left' }}>Risk Score</th>
                  <th style={{ padding: '8px', textAlign: 'left' }}>Risk Level</th>
                </tr>
              </thead>
              <tbody>
                {riskAssessments.map((ra) => {
                  const asset = assets.find(a => a.id === ra.asset_id);
                  const rl = riskLevels[ra.asset_id] || '—';
                  const color = getRiskLevelColor(rl);
                  return (
                    <tr key={ra.id}>
                      <td style={{ padding: '8px' }}>{asset ? asset.name : 'Asset ' + ra.asset_id}</td>
                      <td style={{ padding: '8px' }}>{ra.current_risk_score}</td>
                      <td style={{ padding: '8px', color: color, fontWeight: 'bold' }}>{rl}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Vulnerabilities */}
          <div id="vuln" style={{ marginBottom: '32px' }}>
            <h2 style={{ fontSize: '18px', fontWeight: '500', color: '#08060d', marginBottom: '16px' }}>Vulnerabilities</h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '16px' }}>
              {vulns.map((v) => (
                <div key={v.id} style={{
                  background: 'white', border: '1px solid #e5e4e7', borderRadius: '8px', padding: '16px', margin: '8px 0'
                }}>
                  <h3 style={{ margin: '0 0 4px 0' }}>{v.name}</h3>
                  <p>Severity: {v.severity}/10 | Asset: {v.affected_asset_id}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Threats */}
          <div id="threat" style={{ marginBottom: '32px' }}>
            <h2 style={{ fontSize: '18px', fontWeight: '500', color: '#08060d', marginBottom: '16px' }}>Threats</h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '16px' }}>
              {threats.map((t) => (
                <div key={t.id} style={{
                  background: 'white', border: '1px solid #e5e4e7', borderRadius: '8px', padding: '16px', margin: '8px 0'
                }}>
                  <h3 style={{ margin: '0 0 4px 0' }}>{t.name}</h3>
                  <p>Likelihood: {t.likelihood}/5</p>
                </div>
              ))}
            </div>
          </div>

          {/* Controls */}
          <div id="ctrl" style={{ marginBottom: '32px' }}>
            <h2 style={{ fontSize: '18px', fontWeight: '500', color: '#08060d', marginBottom: '16px' }}>Controls</h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '16px' }}>
              {controls.map((c) => (
                <div key={c.id} style={{
                  background: 'white', border: '1px solid #e5e4e7', borderRadius: '8px', padding: '16px', margin: '8px 0'
                }}>
                  <h3 style={{ margin: '0 0 4px 0' }}>{c.name}</h3>
                  <p>Effectiveness: {c.effectiveness}/10 | Cost: ${c.cost} | Asset: {c.target_asset_id}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Investment Optimization */}
          <div id="invest" style={{ marginBottom: '32px' }}>
            <h2 style={{ fontSize: '18px', fontWeight: '500', color: '#08060d', marginBottom: '16px' }}>Investment Optimization</h2>
            <p>Budget: $50,000</p>
            <p>Selected: ${invOpts.filter(o => o.selected).reduce((s, o) => s + o.cost, 0) || 0}</p>
            <button style={{ display: 'block', width: '100%', padding: '8px 16px', background: '#aa3bff', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer', fontSize: '14px' }}>
              Optimize Investment
            </button>
            <p>Total: ${invOpts.filter(o => o.selected).reduce((s, o) => s + o.cost, 0) || 0} / $50,000</p>
          </div>

          {/* Scenarios */}
          <div id="scenario" style={{ marginBottom: '32px' }}>
            <h2 style={{ fontSize: '18px', fontWeight: '500', color: '#08060d', marginBottom: '16px' }}>Scenario Analysis</h2>
            <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '12px' }}>
              <thead>
                <tr style={{ background: '#f8f9fa', color: '#6b6375' }}>
                  <th style={{ padding: '8px', textAlign: 'left' }}>Scenario</th>
                  <th style={{ padding: '8px', textAlign: 'left' }}>Risk Before</th>
                  <th style={{ padding: '8px', textAlign: 'left' }}>Risk After</th>
                  <th style={{ padding: '8px', textAlign: 'left' }}>Cost</th>
                  <th style={{ padding: '8px', textAlign: 'left' }}>Reduction</th>
                </tr>
              </thead>
              <tbody>
                {scenarios.map((s) => (
                  <tr key={s.id}>
                    <td style={{ padding: '8px' }}>{s.name}</td>
                    <td style={{ padding: '8px' }}>{s.risk_before}</td>
                    <td style={{ padding: '8px' }}>{s.risk_after}</td>
                    <td style={{ padding: '8px' }}>{s.cost}</td>
                    <td style={{ padding: '8px' }}>{s.risk_reduction}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Recommendations */}
          <div id="rec" style={{ marginBottom: '32px' }}>
            <h2 style={{ fontSize: '18px', fontWeight: '500', color: '#08060d', marginBottom: '16px' }}>Prioritized Recommendations</h2>
            <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '12px' }}>
              <thead>
                <tr style={{ background: '#f8f9fa', color: '#6b6375' }}>
                  <th style={{ padding: '8px', textAlign: 'left' }}>Asset</th>
                  <th style={{ padding: '8px', textAlign: 'left' }}>Risk Level</th>
                  <th style={{ padding: '8px', textAlign: 'left' }}>Urgency</th>
                  <th style={{ padding: '8px', textAlign: 'left' }}>Recommendation</th>
                </tr>
              </thead>
              <tbody>
                {recs.map((r) => {
                  const urgencyColors = { Critical: '#dc2626', High: '#f59e0b', Medium: '#eab308', Low: '#10b981' };
                  return (
                    <tr key={r.asset_id}>
                      <td style={{ padding: '8px' }}>{r.asset_name}</td>
                      <td style={{ padding: '8px', color: urgencyColors[r.risk_level] }}>{r.risk_level}</td>
                      <td style={{ padding: '8px', color: urgencyColors[r.urgency] }}>{r.urgency}</td>
                      <td style={{ padding: '8px' }}>{r.recommendation || '—'}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

ReactDOM.render(<App />, document.getElementById('root'));