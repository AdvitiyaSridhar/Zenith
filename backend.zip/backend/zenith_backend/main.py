from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from zenith_backend.routes import router
from zenith_backend.database import get_connection
from zenith_backend.risk_engine import calculate_risk, assess_asset_risk, get_risk_drivers_detail
from zenith_backend.investment_optimizer import optimize_investment, get_control_details
from zenith_backend.recommendation_engine import get_prioritized_recommendations as get_recommendations, get_investment_recommendations as get_invest_recs
from zenith_backend.scenario_analysis import create_scenario, get_scenarios, delete_scenario, compare_scenarios

app = FastAPI(
    title="AI-Powered Cyber Risk Quantification API",
    description="Continuous cyber risk quantification and investment optimization platform",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router, prefix="/api/v1")


@app.get("/")
def root():
    return JSONResponse(content={"message": "API is running"})


@app.get("/health")
def health_check():
    return JSONResponse(content={"status": "healthy"})


# --- Assets API endpoints ---

@app.get("/api/v1/assets")
def list_assets():
    """List all assets."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, description, criticality, value_range, business_process FROM assets")
    rows = cursor.fetchall()
    conn.close()
    return [
        {"id": r[0], "name": r[1], "description": r[2], "criticality": r[3], "value_range": r[4], "business_process": r[5]}
        for r in rows
    ]


@app.get("/api/v1/assets/{asset_id}")
def get_asset(asset_id: int):
    """Get a specific asset by ID."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, description, criticality, value_range, business_process FROM assets WHERE id = ?", (asset_id,))
    row = cursor.fetchone()
    conn.close()
    if row:
        return {"id": row[0], "name": row[1], "description": row[2], "criticality": row[3], "value_range": row[4], "business_process": row[5]}
    return {"error": "Asset not found"}


@app.get("/api/v1/vulnerabilities")
def list_vulnerabilities():
    """List all vulnerabilities."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, description, severity, affected_asset_id FROM vulnerabilities")
    rows = cursor.fetchall()
    conn.close()
    return [
        {"id": r[0], "name": r[1], "description": r[2], "severity": r[3], "affected_asset_id": r[4]}
        for r in rows
    ]


@app.get("/api/v1/threats")
def list_threats():
    """List all threats."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, description, likelihood, target_asset_id FROM threats")
    rows = cursor.fetchall()
    conn.close()
    return [
        {"id": r[0], "name": r[1], "description": r[2], "likelihood": r[3], "target_asset_id": r[4]}
        for r in rows
    ]


@app.get("/api/v1/controls")
def list_controls():
    """List all controls."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, description, effectiveness, cost, target_asset_id FROM controls")
    rows = cursor.fetchall()
    conn.close()
    return [
        {"id": r[0], "name": r[1], "description": r[2], "effectiveness": r[3], "cost": r[4], "target_asset_id": r[5]}
        for r in rows
    ]


@app.get("/api/v1/risk-assessments")
def list_risk_assessments():
    """List all risk assessments."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, asset_id, current_likelihood, current_control_effectiveness, current_risk_score, expected_loss, risk_level FROM risk_assessments")
    rows = cursor.fetchall()
    conn.close()
    return [
        {"id": r[0], "asset_id": r[1], "current_likelihood": r[2], "current_control_effectiveness": r[3], "current_risk_score": r[4], "expected_loss": r[5], "risk_level": r[6]}
        for r in rows
    ]


@app.get("/api/v1/risk-assessments/{asset_id}")
def get_risk_assessment(asset_id: int):
    """Get risk assessment for a specific asset."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, asset_id, current_likelihood, current_control_effectiveness, current_risk_score, expected_loss, risk_level FROM risk_assessments WHERE asset_id = ?", (asset_id,))
    row = cursor.fetchone()
    conn.close()
    if row:
        return {"id": row[0], "asset_id": row[1], "current_likelihood": row[2], "current_control_effectiveness": row[3], "current_risk_score": row[4], "expected_loss": row[5], "risk_level": row[6]}
    return {"error": "Risk assessment not found"}


@app.get("/api/v1/investment-options")
def list_investment_options():
    """List all investment options."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, description, cost, expected_effectiveness FROM investment_options")
    rows = cursor.fetchall()
    conn.close()
    return [
        {"id": r[0], "name": r[1], "description": r[2], "cost": r[3], "expected_effectiveness": r[4]}
        for r in rows
    ]


@app.get("/api/v1/scenarios")
def list_scenarios():
    """List all scenarios."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, description, risk_before, risk_after, cost, risk_reduction FROM scenarios")
    rows = cursor.fetchall()
    conn.close()
    return [
        {"id": r[0], "name": r[1], "description": r[2], "risk_before": r[3], "risk_after": r[4], "cost": r[5], "risk_reduction": r[6]}
        for r in rows
    ]


# --- Recommendation API endpoints ---

@app.get("/api/v1/recommendations/prioritized")
def get_prioritized_recommendations_endpoint():
    """Get prioritized recommendations for the organization."""
    recs = get_recommendations()
    return JSONResponse(content=recs)


@app.get("/api/v1/recommendations/investment/{budget}")
def get_investment_recommendations_endpoint(budget: int):
    """Get investment recommendations based on available budget."""
    recs = get_invest_recs(budget)
    return JSONResponse(content=recs)


# --- Scenario API endpoints ---

@app.get("/api/v1/scenarios")
def get_scenarios_api():
    """Get all scenarios."""
    scenarios = get_scenarios()
    return scenarios


@app.get("/api/v1/scenarios/compare")
def compare_scenarios_api(scenario_ids: str = ""):
    """Compare multiple scenarios side by side."""
    scenario_ids_list = [int(x) for x in scenario_ids.split(",") if x.strip()] if scenario_ids else []
    comparison = compare_scenarios(scenario_ids_list)
    return comparison